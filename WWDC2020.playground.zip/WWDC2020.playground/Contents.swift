import SpriteKit
import PlaygroundSupport
/*:
 ## Wind Tunnel Simulation
 _ _ _
Hi! I used to study aerospace engineering! It is a fascinating subject to me. in this simple playground, I want to share a little that interests me in the subject. This is a simple wind tunnel simulator. There is a wing located in the center of the screen. You can move it around by dragging it and see how it affects the air around it!
_ _ _

 */
//: ### Start exploring by running the function below

startSimulation()

//: _ _ _
/*:
 ### Assets:
 * [[1]](https://opengameart.org/content/sky-backdrop) Sky Backdrops - OpenGameArts.org

 */




