import SpriteKit
import PlaygroundSupport

public func startSimulation() {
    let skView = SKView(frame: CGRect(x:0 , y:0, width: 800, height: 600))
    //let skView = SKView(frame: .zero)

    //let gameScene = GameScene(size: UIScreen.main.bounds.size)
    let gameScene = GameScene(size: CGSize(width: 800, height: 600))
    gameScene.scaleMode = .aspectFill
    skView.presentScene(gameScene)


    PlaygroundPage.current.liveView = skView
}
