
import Foundation
import SpriteKit

public class GameScene: SKScene, SKPhysicsContactDelegate {
    
    
    //variable
    let numberOfParticle = 20
    var gameOver = false
    var movingPlayer = false
    var offset: CGPoint!
    
    
    var player: SKSpriteNode!
    var people = [SKSpriteNode]()
    
    
    func distanceY(d: Double, min:CGFloat, max: CGFloat) -> CGFloat{
        return CGFloat(d) * (max-min)+min
    }
    
    
    public override func didMove(to view: SKView) {
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.friction = 0.0
        physicsWorld.contactDelegate = self
        
        self.backgroundColor = .black
        
        // background
        let bg = SKSpriteNode(texture: SKTexture(imageNamed: "sky1"))
        bg.setScale(1.0)
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(bg)
        
        
        
        // Player
        player = SKSpriteNode(texture: SKTexture(imageNamed: "wingSideView"), color: .clear, size: CGSize(width: size.width * 0.2, height: size.height * 0.05))
        player.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(player)
        
        player.physicsBody = SKPhysicsBody(texture: player.texture!, size: CGSize(width: size.width * 0.2, height: size.height * 0.05))
        player.physicsBody?.isDynamic = false
        player.physicsBody?.affectedByGravity = false
        player.physicsBody?.allowsRotation = false
//        player.physicsBody?.density = 100.0
        player.physicsBody?.categoryBitMask = BitMasks.player
        player.physicsBody!.collisionBitMask = BitMasks.air
        
        // outflow
        let outflow = SKShapeNode(rectOf: CGSize(width: 5, height: 700))
        outflow.name = "outflow"
        outflow.fillColor = .blue
        outflow.position = CGPoint(x: frame.minX, y: frame.midY)
        outflow.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 5, height: 700))
        outflow.physicsBody?.isDynamic = false
        outflow.physicsBody?.categoryBitMask = BitMasks.outflow
        outflow.physicsBody!.contactTestBitMask = BitMasks.air
        
        addChild(outflow)
        
        
        let spawn = SKAction.run(createAirParticle)
        let waitToSpawn = SKAction.wait(forDuration: 0.25)
        let spawnSequence = SKAction.sequence([waitToSpawn, spawn])
        let spawnForever = SKAction.repeatForever(spawnSequence)
        self.run(spawnForever)
        
        
    }
    
    
    func createAirParticle() {
        let radius = 5
        
        for particle in 1...numberOfParticle {
            let particleDouble = Double(particle)
            let totalParticleDouble = Double(numberOfParticle)
            let temp = particleDouble/totalParticleDouble
            
            let randomYStart = distanceY(d: temp, min: frame.minY, max: frame.maxY)
            
            let startPoint = CGPoint(x : self.size.width, y: randomYStart)
            
            let air = SKShapeNode(circleOfRadius: CGFloat(radius))
            air.fillColor = .yellow
            air.name = "air"
            air.position = startPoint
            air.zPosition = 2
            air.physicsBody = SKPhysicsBody(circleOfRadius: CGFloat(radius))
            air.physicsBody?.affectedByGravity = false
            air.physicsBody?.allowsRotation = true
            air.physicsBody?.isDynamic = true
            air.physicsBody?.friction = 0.0
//            air.physicsBody?.density = 1.225
            air.physicsBody?.angularDamping = 0.0
            air.physicsBody?.restitution = 0.0
            air.physicsBody?.linearDamping = 0.0
            air.physicsBody?.categoryBitMask = BitMasks.air
            air.physicsBody!.collisionBitMask = BitMasks.player | BitMasks.air
            air.physicsBody!.contactTestBitMask = BitMasks.outflow
            
            self.addChild(air)
            
            
//            let moveair = SKAction.applyForce(CGVector(dx: -1, dy: 0.0), duration: 1)
            
            
//            let airSequence = SKAction.sequence([moveair])
            air.run(SKAction.applyForce(CGVector(dx: -1, dy: 0.0), duration: 1))
            
        }
        
        
    }
    
    
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver else {
            return
        }
        guard let touch = touches.first else { return }
        let touchLocation = touch.location(in: self)
        let touchedNodes = nodes(at: touchLocation)
        
        for _ in touchedNodes {
            movingPlayer = true
            offset = CGPoint(x: touchLocation.x - player.position.x, y: touchLocation.y - player.position.y)
            
        }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver && movingPlayer else {
            return
        }
        guard let touch = touches.first else { return }
        let touchLocation = touch.location(in: self)
        let newPlayerPosition = CGPoint(x: touchLocation.x - offset.x, y: touchLocation.y - offset.y)
        
        player.run(SKAction.move(to: newPlayerPosition, duration: 0.01))
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        movingPlayer = false
    }
    
    public func didBegin (_ contact: SKPhysicsContact) {
        
        if contact.bodyA.categoryBitMask == BitMasks.outflow && contact.bodyB.categoryBitMask == BitMasks.air {
            // if the player hit the air
            contact.bodyB.node!.removeFromParent()
            
        }
            
        else if contact.bodyA.categoryBitMask == BitMasks.air && contact.bodyB.categoryBitMask == BitMasks.outflow {
            // if the player hit the air
            contact.bodyA.node!.removeFromParent()
            
        }
        
        
    }
}
