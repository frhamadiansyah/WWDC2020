import Foundation

struct BitMasks {
    static let player : UInt32 = 0b1 //1
    static let air : UInt32 = 0b10 //2
    static let outflow : UInt32 = 0b100 //3
}
